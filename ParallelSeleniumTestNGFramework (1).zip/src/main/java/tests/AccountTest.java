package tests;

import base.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import utils.TestDataProvider;
import io.qameta.allure.Description;
import java.util.List;
import java.util.Map;

public class AccountTest {

    @Parameters("browser")
    @BeforeMethod
    public void setup(String browser) {
        DriverManager.initDriver(browser);
    }

    @Test(dataProvider = "accountData", dataProviderClass = TestDataProvider.class)
    @Description("Processes account data using parallel execution with browser parameter")
    public void processAccounts(Map<String, String> user, List<Map<String, String>> accounts) {
        WebDriver driver = DriverManager.getDriver();
        // Dummy login + account edit simulation
        login(user.get("username"), user.get("password"));

        for (Map<String, String> account : accounts) {
            System.out.println("User: " + user.get("username") + " -> Processing: " + account.get("accountId"));
            // Placeholder for actual UI interaction
        }
    }

    @AfterMethod
    public void teardown() {
        DriverManager.quitDriver();
    }

    private void login(String username, String password) {
        System.out.println("Logging in with: " + username + " / " + password);
    }
}