package utils;

import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.util.*;

public class ExcelUtil {

    public static List<Map<String, String>> readSheetAsMap(String filePath, String sheetName) {
        List<Map<String, String>> dataList = new ArrayList<>();
        try (Workbook wb = WorkbookFactory.create(new File(filePath))) {
            Sheet sheet = wb.getSheet(sheetName);
            Row headerRow = sheet.getRow(0);

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                Map<String, String> rowData = new HashMap<>();
                for (int j = 0; j < row.getLastCellNum(); j++) {
                    String key = headerRow.getCell(j).getStringCellValue();
                    String value = row.getCell(j).toString();
                    rowData.put(key, value);
                }
                dataList.add(rowData);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dataList;
    }
}