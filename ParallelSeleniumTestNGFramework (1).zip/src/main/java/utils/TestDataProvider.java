package utils;

import org.testng.annotations.DataProvider;

import java.util.*;

public class TestDataProvider {

    private static final String FILE_PATH = "src/main/resources/testdata.xlsx";

    @DataProvider(name = "accountData", parallel = true)
    public Object[][] provideAccountData() {
        List<Map<String, String>> users = ExcelUtil.readSheetAsMap(FILE_PATH, "users");
        List<Map<String, String>> accounts = ExcelUtil.readSheetAsMap(FILE_PATH, "accounts");

        int threads = users.size();
        int chunkSize = accounts.size() / threads;

        List<Object[]> data = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            Map<String, String> user = users.get(i);
            List<Map<String, String>> chunk = accounts.subList(
                    i * chunkSize,
                    i == threads - 1 ? accounts.size() : (i + 1) * chunkSize
            );

            data.add(new Object[]{user, chunk});
        }

        return data.toArray(new Object[0][]);
    }
}